import cv2
import os

def split_video_to_images(video_path, output_folder, num_frames):
    # 创建输出文件夹
    os.makedirs(output_folder, exist_ok=True)

    # 使用OpenCV读取视频文件
    video = cv2.VideoCapture(video_path)
    total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
    frame_interval = total_frames // num_frames

    # 逐帧读取视频并保存图片
    count = 0
    frame_index = 0
    while video.isOpened():
        ret, frame = video.read()
        if not ret:
            break
        if count % frame_interval == 0:
            output_path = os.path.join(output_folder, f"frame_{frame_index}.jpg")
            cv2.imwrite(output_path, frame)
            frame_index += 1
        count += 1
        if frame_index == num_frames:
            break

    # 释放视频资源
    video.release()